import { TIME } from './Words/TIME';
import { HOME } from './Words/HOME';
import { PERSON } from './Words/PERSON';
import { YOU } from './Words/YOU';

var wordList = ['TIME', 'HOME', 'PERSON', 'YOU'];

export {
    TIME, HOME, PERSON, YOU, wordList
}