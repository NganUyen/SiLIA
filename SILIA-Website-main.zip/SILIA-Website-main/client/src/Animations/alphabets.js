import { A } from './Alphabets/A';
import { B } from './Alphabets/B';
import { C } from './Alphabets/C';
import { D } from './Alphabets/D';
import { E } from './Alphabets/E';
import { F } from './Alphabets/F';
import { G } from './Alphabets/G';
import { H } from './Alphabets/H';
import { I } from './Alphabets/I';
import { J } from './Alphabets/J';
import { K } from './Alphabets/K';
import { L } from './Alphabets/L';
import { M } from './Alphabets/M';
import { N } from './Alphabets/N';
import { O } from './Alphabets/O';
import { P } from './Alphabets/P';
import { Q } from './Alphabets/Q';
import { R } from './Alphabets/R';
import { S } from './Alphabets/S';
import { T } from './Alphabets/T';
import { U } from './Alphabets/U';
import { V } from './Alphabets/V';
import { W } from './Alphabets/W';
import { X } from './Alphabets/X';
import { Y } from './Alphabets/Y';
import { Z } from './Alphabets/Z';

export {
    A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z
}